const { User } = require("../models/saveDataModel");

exports.getData = async (req, res) => {
  try {
    var users = await User.findOne({ _id: req.body._id });
    res.status(200).json({ message: "User Details.", data: users });
  } catch (error) {
    res.status(500).json({
      message: `Server Error`,
      error: error,
    });
  }
};
