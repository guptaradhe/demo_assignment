const { User } = require("../models/saveDataModel");
const functions = require("../helper/helper");

exports.saveData = async (req, res) => {
  const validationRule = {
    email_id: "required",
  };

  try {
    const result = functions.validator(req.body, validationRule);

    if (!result.status) {
      let error_message_array = Object.values(result.err.errors);
      let error_message_data = error_message_array[0];
      let error_message = error_message_data[0];
      res.status(400).json({
        message: error_message,
      });
    } else {
      // for age in the basis of dob
      function calculateAge(birthdateString) {
        const parts = birthdateString.split("-");
        const day = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10);
        const year = parseInt(parts[2], 10);

        const birthdate = new Date(year, month - 1, day);

        const currentDate = new Date();
        const ageInMilliseconds = currentDate - birthdate;
        const ageInYears = Math.floor(
          ageInMilliseconds / (365 * 24 * 60 * 60 * 1000)
        );

        return ageInYears;
      }

      // Example usage:
      const birthdateString = req.body.dob;
      const age = calculateAge(birthdateString);

      const user = new User({
        first_name: req.body.first_name,
        last_name: req.body.last_name,
        email_id: req.body.email_id,
        country: req.body.country,
        state: req.body.state,
        city: req.body.city,
        gender: req.body.gender,
        dob: req.body.dob,
        age: age,
      });
      await user.save();

      return res.status(200).json({
        message: `User data added successfully.`,
      });
    }
  } catch (error) {
    res.status(500).json({
      message: `Server Error`,
      error: error,
    });
  }
};
