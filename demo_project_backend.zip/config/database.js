const mongoose = require("mongoose");
// Connect to MongoDB database
mongoose
  .connect("mongodb://0.0.0.0:27017/demo_api_mongo", { useNewUrlParser: true })
  .then(() => {
    console.log("database connected...");
  })
  .catch((err) => {
    console.log(err);
  });
  
exports.mongoose = mongoose;