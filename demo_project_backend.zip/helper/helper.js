const validator = require("validatorjs");

exports.validator = (body, rules) => {
    const validation = new validator(body, rules);
    let result = {};
    validation.passes(() => {
      result = {
        err: null,
        status: true,
      };
    });
    validation.fails(() => {
      result = {
        err: validation.errors,
        status: false,
      };
    });
    return result;
  };
  

  