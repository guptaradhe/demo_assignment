
import React, {  useState } from 'react'
// import $ from 'jquery'
import axios from 'axios'



const User = () => {
  const [firstName, setFirstName] = useState('')
  const [lastName, setLastName] = useState('')
  const [email, setEmail] = useState('')
  const [country, setCountry] = useState('')
  const [state, setState] = useState('')
  const [city, setCity] = useState('')
  const [gender, setGender] = useState('')
  const [dob, setDOB] = useState('')
  const saveUserData = async () => {
    const body = {
        first_name: firstName,
        last_name: lastName,
        email_id: email,
        country: country,
        state: state,
        city: city,
        gender: gender,
        dob: dob
    }
    await axios.post('http://localhost:3000/users/save-data', body).then((res) => res)

  }
  const refesh = () => window.location.reload(true)
  

  return (
    <>
          <section style={{ backgroundColor: '#eee' }}>
              <div class="container py-5">
                  <div class="row">
                      <div class="col-lg-12">
                          <div class="card mb-4">
                              <div class="card-body">
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">First Name</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setFirstName(e.target.value)} onkeypress="return false;"/>
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">Last Name</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setLastName(e.target.value)} />
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">Email Id</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setEmail(e.target.value)} />
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">Country Name</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setCountry(e.target.value)} />
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">State Name</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setState(e.target.value)} />
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">City Name</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setCity(e.target.value)} />
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">Gender</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setGender(e.target.value)} />
                                      </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-sm-5 element">
                                          <p class="mb-0">Date of birth</p>
                                      </div>
                                      <div class="col-sm-5">
                                          <input type="text" onChange={(e) => setDOB(e.target.value)} />
                                      </div>
                                  </div>
                              </div>

                          </div>
                          <br/>
                          <div class="col-lg-12 justify-content-between d-flex">
                              <button type="button" class="bg-black text-white py-1 px-2" onClick={() => {
                                  refesh()
                              } }
                              >
                                  Cancel
                              </button>

                              <button type="button" class="bg-black text-white py-1 px-2" onClick={() => {
                                  saveUserData()
                                  refesh()
                              } }
                              >
                                  Save
                              </button>
                          </div>
                      </div>
                  </div>
              </div>
          </section>
      </>
  )
}

export default User


// function User() {
//     return (
//         <div>
//             <h1>User component</h1>
//             <h1>Hello Nisha</h1>
//             <h1>Hello Akhil</h1>
//         </div>
//     )
// }

// function User1() {
//     return (
//         <div>
//             <h1>User component</h1>
//             <h1>Hello Nisha Sharma</h1>
//             <h1>Hello Akhil Pandey</h1>
//         </div>
//     )
// }
// export default (User, User1);


