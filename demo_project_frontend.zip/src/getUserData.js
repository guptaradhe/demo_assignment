import React, { useEffect, useState } from "react";

import axios from "axios";

function Users() {
  const [users, setUser] = useState([]);
  const body = {
    id: user_id,
  };

  const loadUsers = async () => {
    await axios
      .post("http://localhost:3000/users/save-data", body)
      .then((response) => {
        setUser(response.data.data);
        // console.log(response.data.data)
      })
      .catch((error) => {
        console.log(error);
      });
  };
  useEffect(() => {
    loadUsers();
  }, []);
  // console.log(users, 'yy')
  return (
    <>
      <h1>users</h1>
    </>
  );
}

export default Users;
